#!/usr/bin/env bash

# Script to execute TFlint linting by finding all dirs with "main.tf"


shopt -s lastpipe
tflint --init

COUNTER=0
find ../../../ -type f -name "main.tf" -not -path "*/test/*" -not -path "*/gcp/*" -not -path "*/dev/*" -exec dirname {} \; | \
while read line; do 
    echo "***** TFlinting $line *****"
    (tflint $line)
    if [ $? != 0 ]; then
        sleep 1
        echo $COUNTER
        COUNTER=`expr $COUNTER + 1`
    else
        echo "***** Success! *****'"
    fi
done
if [ $COUNTER -ne 0 ]; then
    echo "#----------- There were linting errors. Please review and resubmit changes. -----------#"
    exit 1
else
    echo '***** DONE *****'
fi
