#!/usr/bin/env bash

# Script for automated pipeline to take the exit codes from Terraform plan to conditionally apply or exit


set +e

terraform plan -detailed-exitcode
if [ $? -eq 0 ]; then
  echo "No changes, not applying"
elif [ $? -eq 1 ] || [ $? -eq 2 ]; then
  terraform apply -auto-approve
fi