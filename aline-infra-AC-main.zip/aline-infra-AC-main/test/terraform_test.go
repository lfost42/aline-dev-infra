package test

import (
	"fmt"
	"github.com/gruntwork-io/terratest/modules/aws"
	"github.com/gruntwork-io/terratest/modules/terraform"
	test_structure "github.com/gruntwork-io/terratest/modules/test-structure"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"testing"
)

const savedAwsRegion = "AwsRegion"

func TestTerraformModules(t *testing.T) {
	t.Parallel()
	workingDir := "../environments/test"
	awsRegion := "us-east-1"

	defer test_structure.RunTestStage(t, "cleanup", func() {
		destroyTerraform(t, workingDir)
	})

	test_structure.RunTestStage(t, "deploy", func() {
		test_structure.SaveString(t, workingDir, savedAwsRegion, awsRegion)
		deployUsingTerraform(t, awsRegion, workingDir)
	})

	// Validate that subnets are public and private
	test_structure.RunTestStage(t, "validate", func() {
		validateVPC(t, workingDir, awsRegion)
	})

	// Validate that EC2 tags are correct
	test_structure.RunTestStage(t, "validate", func() {
		validateEC2Tags(t, workingDir, awsRegion)
	})

	// // Validate that SSH actions are functioning
	// test_structure.RunTestStage(t, "validate", func() {
	// 	validateSSH(t, workingDir, awsRegion)
	// })

}

func destroyTerraform(t *testing.T, workingDir string) {
	terraformOptions := test_structure.LoadTerraformOptions(t, workingDir)
	terraform.Destroy(t, terraformOptions)
}

func deployUsingTerraform(t *testing.T, awsRegion string, workingDir string) {
	terraformOptions := &terraform.Options{
		TerraformDir: workingDir,
	}

	test_structure.SaveTerraformOptions(t, workingDir, terraformOptions)
	terraform.InitAndApply(t, terraformOptions)
}

func validateVPC(t *testing.T, workingDir string, awsRegion string) {
	terraformOptions := test_structure.LoadTerraformOptions(t, workingDir)

	vpcId := terraform.Output(t, terraformOptions, "vpc_out")
	pubSubnetIds := terraform.OutputList(t, terraformOptions, "pubsub_out")
	privSubnetIds := terraform.OutputList(t, terraformOptions, "privsub_out")
	subnets := aws.GetSubnetsForVpc(t, vpcId, awsRegion)

	require.Equal(t, 4, len(subnets))

	for _, element := range pubSubnetIds {
		isPublic, err := aws.IsPublicSubnetE(t, element, awsRegion)
		if err != nil {
			fmt.Printf("Error: %s", err)
			return
		}
		assert.True(t, isPublic)
	}

	for _, element := range privSubnetIds {
		isPrivate, err := aws.IsPublicSubnetE(t, element, awsRegion)
		if err != nil {
			fmt.Printf("Error: %s", err)
			return
		}
		assert.False(t, isPrivate)
	}
}

func validateEC2Tags(t *testing.T, workingDir string, awsRegion string) {
	terraformOptions := test_structure.LoadTerraformOptions(t, workingDir)
	instanceID := terraform.Output(t, terraformOptions, "ec2_out")
	aws.AddTagsToResource(t, awsRegion, instanceID, map[string]string{"testing": "testing-tag-value"})
	instanceTags := aws.GetTagsForEc2Instance(t, awsRegion, instanceID)

	// website::tag::3::Check if the EC2 instance with a given tag and name is set.
	testingTag, containsTestingTag := instanceTags["testing"]
	assert.True(t, containsTestingTag)
	assert.Equal(t, "testing-tag-value", testingTag)

	// Verify that our expected name tag is one of the tags
	nameTag, containsNameTag := instanceTags["Name"]
	assert.True(t, containsNameTag)
	assert.Equal(t, "ac_ec2", nameTag)
}

// func validateSSH(t *testing.T, workingDir string, awsRegion string) {
// 	terraformOptions := test_structure.LoadTerraformOptions(t, workingDir)

// 	publicInstanceIP := terraform.Output(t, terraformOptions, "ec2ip_out")
// 	keyPair := aws.ImportEC2KeyPair(t, awsRegion, "ac", ac-ansible)

// 	publicHost := ssh.Host{
// 		Hostname:    publicInstanceIP,
// 		SshKeyPair:  keyPair,
// 		SshUserName: "ec2-user",
// 	}
// 	fmt.Printf(keyPair)
// }
 stretch goal 