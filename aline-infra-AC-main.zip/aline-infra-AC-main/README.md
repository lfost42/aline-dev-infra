# aline-infra-AC

Aline Financial microservices cloud provisioning via Terraform

Provider: AWS
Hashicorp/AWS Version: ~> 4.3
Terraform Version: >= 1.2
